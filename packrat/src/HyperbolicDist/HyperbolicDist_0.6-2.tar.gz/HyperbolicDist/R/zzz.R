### Create the matrix hyperbWSqTable for use in hyperbCvMTestPValue.R
### This is Table 5 from Puig & Stephens (2001)
data(hyperbWSqTable)
